package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 19.7.2019

// This activity demonstrates how to use the View method animate()
// and in consequence a ViewPropertyAnimator to animate various properties of View objects.

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

public class ViewPropertyAnimatorActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpropertyanimator_animation);
    }

    //
    // Method to animate two views
    //

    public void startAnimation(View v) {

        int duration = 1500;  // duration of the animation in ms
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        //
        // Animation of View A: animate a single property - x position
        //

        View viewA = findViewById(R.id.viewA);
        viewA.animate().x(2*screenWidth/3).setDuration(duration).start();
            // animate() returns a ViewPropertyAnimator for the object.
            // x() specifies the target x position of the View in the animation.

        //
        // Animation of ViewB: animate multiple properties: x position, y position, size, rotation, transparency
        //

        View viewB = findViewById(R.id.viewB);
        viewB.animate().x(3*screenWidth/5).y(3*screenHeight/4).scaleX(2.0f).scaleY(2.0f).rotation(360).alpha(0.2f).setDuration(duration).start();

    }

    public void reset(View v) {

        setContentView(R.layout.viewpropertyanimator_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation = "<H2>Property Animation: ViewPropertyAnimator</H2>" +
                "The easiest way to program a property animation is to use a <font face=\"Courier\">ViewPropertyAnimator</font> object.<P>" +
                "<B>Creation and specification</B><P>" +
                "A view property animator for a <font face=\"Courier\">View</font> object is obtained through its " +
                "method <font face=\"Courier\">animate()</font>. " +
                "It provides methods like " +
                "<font face=\"Courier\">x()</font>, <font face=\"Courier\">y()</font>, <font face=\"Courier\">rotation()</font>, " +
                "etc. to specify the properties to be animated with their target values, " +
                "<font face=\"Courier\">setDuration()</font> to set the duration of the animation and " +
                "<font face=\"Courier\">start()</font> to start it.<P>" +
                "As all these methods (except <font face=\"Courier\">start()</font>) return the same view property animator " +
                "on which they are called, the calls can be chained.<P>" +
                "<B>Example code</B><P>" +
                "The program code of this demo app is:<P>" +
                "- for ViewA:<BR><font face=\"Courier\">viewA.animate().<BR>" +
                "&nbsp;&nbsp;x(2*screenWidth/3).<BR>&nbsp;&nbsp;setDuration(1500).<BR>&nbsp;&nbsp;start();</font><P>" +
                "- for ViewB:<BR><font face=\"Courier\">viewB.animate().<BR>" +
                "&nbsp;&nbsp;x(3*screenWidth/5).<BR>&nbsp;&nbsp;y(3*screenHeight/4).<BR>&nbsp;&nbsp;scaleX(2.0f).<BR>" +
                "&nbsp;&nbsp;scaleY(2.0f).<BR>&nbsp;&nbsp;rotation(360)." +
                "<BR>&nbsp;&nbsp;alpha(0.2f).<BR>&nbsp;&nbsp;setDuration(1500).<BR>&nbsp;&nbsp;start();</font><P>" +
                "This technique has, however, its limitations:" +
                "<UL><LI>It can be applied only to <font face=\"Courier\">View</font> objects." +
                "<LI>It can be applied only to some fundamental properties (position, size, rotation, transparency)." +
                "<LI>The intermediate values are always calculated by a linear interpolation between start and end value." +
                "</UL>";


        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ViewPropertyAnimator_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_viewpropertyanimator+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/view/ViewPropertyAnimator.html")).show();
    }

}
