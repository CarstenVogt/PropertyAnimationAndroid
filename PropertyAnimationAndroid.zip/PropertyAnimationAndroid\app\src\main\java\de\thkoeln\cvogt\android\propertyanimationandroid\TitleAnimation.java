package de.thkoeln.cvogt.android.propertyanimationandroid;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

public class TitleAnimation extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.title_animation);
        final FrameLayout layout = (FrameLayout) findViewById(R.id.layout);

        layout.post(new Runnable() {

            public void run() {

                View layout = findViewById(R.id.layout);
                int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
                int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
                layout.setMinimumWidth(screenWidth);
                layout.setMinimumHeight(screenHeight);

                View vogt = findViewById(R.id.vogt);
                View logo = findViewById(R.id.logo);
                View android = findViewById(R.id.android);
                View property = findViewById(R.id.property);
                View animation = findViewById(R.id.animation);
                View button = findViewById(R.id.closebutton);

                button.animate().x(screenWidth-1.2f*button.getWidth()-100).y(3*screenHeight/4).scaleX(1.2f).scaleY(1.2f).rotation(-360).setDuration(500).start();

                logo.animate().x(0).y(screenHeight/3).scaleX(0.7f).scaleY(0.7f).rotation(360)
                        .setInterpolator(new BounceInterpolator()).setStartDelay(500).setDuration(2000).start();

                int yPos = screenHeight/8 + android.getHeight() + property.getHeight() + animation.getHeight() +120;
                vogt.animate().x((screenWidth-vogt.getWidth())/2-20).y(yPos).setInterpolator(new OvershootInterpolator())
                        .setStartDelay(2000).setDuration(1500).start();

                android.animate().x((screenWidth-android.getMeasuredWidth())/2-20).y(screenHeight/8).setStartDelay(3500).setDuration(1000).start();

                property.animate().x((screenWidth-property.getWidth())/2-20).y(screenHeight/8+android.getHeight()+10).setStartDelay(3600).setDuration(1000).start();

                animation.animate().x((screenWidth-animation.getWidth())/2-20).y(screenHeight/8+android.getHeight()+property.getHeight()+20).setStartDelay(3700).setDuration(1000).start();

            }
        });

    }

    public void closeintro(View v) {
        finish();
    }

}
