package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class Utils {

    public static void showPDF(Activity callingActivity, String pdfUriString) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(pdfUriString), "application/pdf");
        try {
            callingActivity.startActivity(intent);
        }
        catch (ActivityNotFoundException e) {
            Toast.makeText(callingActivity,
                    "No PDF viewer installed",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /** Popup window to display plain text in a ScrollView.
     */

    public static class TextoutputPopup extends PopupWindow {

        ScrollView scrollView;

        /** Constructor
         *
         * @param context Context (= activity) using this popup window
         * @param text Text to be displayed.
         */

        public TextoutputPopup(final Context context, final String text) {
            this(context,text,22);
        }

        /** Constructor
         *
         * @param context Context (= activity) using this popup window.
         * @param text Text to be displayed.
         * @param textSize Font size of the text.
         */

        public TextoutputPopup(final Context context, final String text, final int textSize) {
            super(context);
            // Generate TextViews for the prompt texts
            TextView textView = new TextView(context);
            textView.setText(text);
            textView.setTextSize(textSize);
            // Generate a button to transfer the inputs to the calling activity and to close the window
            Button closeButton = new Button(context);
            closeButton.setText("Close");
            closeButton.setTextSize(textSize);
            // Listener to return the input values and to close the window
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Close the window
                    dismiss();
                }
            });
            // Generate the layout
            LinearLayout layout = new LinearLayout(context);
            layout.setBackgroundColor(0xFFFFFFFF);
            layout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
            layoutParams.setMargins(50,15,50,0);
            layout.setLayoutParams(layoutParams);
            layout.addView(textView);
            layout.addView(closeButton);
            scrollView = new ScrollView(context);
            scrollView.setBackgroundColor(0xFFFFFFFF);
            scrollView.setLayoutParams(layoutParams);
            scrollView.addView(layout);
            setContentView(scrollView);
            setFocusable(true);
        }

        /** Display the PopupWindow at a specific location with a specific size.
         *
         * @param left X coordinate of the top left corner
         * @param top Y coordinate of the top left corner
         * @param width Width of the window
         * @param height Height of the window
         */

        public void show(int left, int top, int width, int height) {
            showAtLocation(scrollView, Gravity.TOP| Gravity.LEFT, left, top);
            update(left,top,width,height);
        }

        /**
         * Display the PopupWindow at a standard location with a standard size.
         */

        public void show() {
            final int left = 20;
            final int top = 100;
            show(left,top,Resources.getSystem().getDisplayMetrics().widthPixels-left,-1);
        }

    }

    /** Popup window to display a HTML formatted text.
     */

    public static class HTMLOutputPopup extends PopupWindow {

        LinearLayout layout;

        /** Constructor
         *
         * @param context Context (= activity) using this popup window
         * @param htmlString HTML formatted text to be displayed.
         */

        public HTMLOutputPopup(final Context context, final String htmlString) {
            super(context);
            // Generate a WebView
            final WebView webView = new WebView(context);
            // To load everything into the WebView, i.e. never call an external browser as e.g. Firefox:
            webView.setWebViewClient(
                    new WebViewClient() {
                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                            view.loadUrl(url);
                            return true;
                        }
                    });
            // To allow zooming with a two-finger gesture
            WebSettings webSettings = webView.getSettings();
            webSettings.setDisplayZoomControls(false);
            webSettings.setBuiltInZoomControls(true);
            // Generate a button to close the window
            Button closeButton = new Button(context);
            closeButton.setText("Close");
            closeButton.setTypeface(closeButton.getTypeface(), Typeface.BOLD_ITALIC);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.RIGHT;
            // lp.rightMargin = -80;
            // lp.topMargin = -60;
            closeButton.setLayoutParams(lp);
            closeButton.setBackgroundColor(0xFFFFFFFF);
            // closeButton.setTextSize(textSize);
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Close the window
                    dismiss();
                }
            });
            // Generate the layout
            // layout = new FrameLayout(context);
            layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
            layoutParams.setMargins(50,15,50,0);
            layout.setLayoutParams(layoutParams);
            layout.addView(closeButton);
            layout.addView(webView);
            setContentView(layout);
            setFocusable(true);
            webView.loadData(htmlString,"text/html","utf-8");
        }

        /** Display the PopupWindow at a specific location with a specific size.
         *
         * @param left X coordinate of the top left corner
         * @param top Y coordinate of the top left corner
         * @param width Width of the window
         * @param height Height of the window
         */

        public void show(int left, int top, int width, int height) {
            showAtLocation(layout, Gravity.TOP|Gravity.LEFT, left, top);
            update(left,top,width,height);
        }

        /**
         * Display the PopupWindow at a standard location with a standard size.
         */

        public void show() {
            final int left = 20;
            final int top = 100;
            show(left,top,Resources.getSystem().getDisplayMetrics().widthPixels-left,-1);
        }

    }

    /** Popup window to display a Web page.
     */

    public static class WebViewPopup extends PopupWindow {

        LinearLayout layout;

        /** Constructor
         *
         * @param context Context (= activity) using this popup window
         * @param urlString URL of the Web page to be displayed.
         */

        public WebViewPopup(final Context context, final String urlString) {
            super(context);
            Toast toast = Toast.makeText(context,"Please wait for the page to load",Toast.LENGTH_LONG);
            toast.setGravity(Gravity.TOP,0,0);
            toast.show();
            // Generate a WebView
            final WebView webView = new WebView(context);
            // To load everything into the WebView, i.e. never call an external browser as e.g. Firefox:
               webView.setWebViewClient(
                    new WebViewClient() {
                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                            view.loadUrl(url);
                            return true;
                        }
                    });
            // To allow zooming with a two-finger gesture
            WebSettings webSettings = webView.getSettings();
            webSettings.setDisplayZoomControls(false);
            webSettings.setBuiltInZoomControls(true);
            // To enable JavaScript
            webSettings.setJavaScriptEnabled(true);
            webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
            webSettings.setDomStorageEnabled(true);
            // Generate a button to close the window
            Button closeButton = new Button(context);
            closeButton.setText("Close");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.RIGHT;
            closeButton.setLayoutParams(lp);
            closeButton.setBackgroundColor(0xFFFFFFFF);
            closeButton.setTypeface(closeButton.getTypeface(), Typeface.BOLD_ITALIC);
            // closeButton.setTextSize(textSize);
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Close the window
                    dismiss();
                }
            });
            // Generate the layout
            // layout = new FrameLayout(context);
            layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
            layoutParams.setMargins(50,15,50,0);
            layout.setLayoutParams(layoutParams);
            layout.addView(closeButton);
            layout.addView(webView);
            setContentView(layout);
            setFocusable(true);
            if (internetAvailable(context))
               webView.loadUrl(urlString);
             else webView.loadData("<B>No network available</B>","text/html","utf-8");
        }

        /** Display the PopupWindow at a specific location with a specific size.
         *
         * @param left X coordinate of the top left corner
         * @param top Y coordinate of the top left corner
         * @param width Width of the window
         * @param height Height of the window
         */

        public void show(int left, int top, int width, int height) {
            showAtLocation(layout, Gravity.TOP| Gravity.LEFT, left, top);
            update(left,top,width,height);
        }

        /**
         * Display the PopupWindow at a standard location with a standard size.
         */

        public void show() {
            final int left = 20;
            final int top = 100;
            show(left, top, Resources.getSystem().getDisplayMetrics().widthPixels-left,-1);
        }

    }

    /** Popup window to display a video.
     */

    public static class VideooutputPopup extends PopupWindow {

        LinearLayout layout;
        Context context;

        /** Constructor
         *
         * @param context Context (= activity) using this popup window.
         * @param videoFilename name of the video to be displayed (as given in R.raw).
         */

        public VideooutputPopup(final Context context, final String videoFilename) {
        // public VideooutputPopup(final Context context, final String videoUriString) {
            super(context);
            this.context = context;
            VideoView videoView = new VideoView(context);
            final MediaController mediaController = new MediaController(context);
            mediaController.setAnchorView(videoView);
            videoView.setMediaController(mediaController);
            // videoView.setVideoURI(Uri.parse(videoUriString));
            videoView.setVideoPath("android.resource://" + context.getPackageName() + "/" + videoFilename);
            Button closeButton = new Button(context);
            closeButton.setText("Close");
            closeButton.setTypeface(closeButton.getTypeface(), Typeface.BOLD_ITALIC);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.RIGHT;
            closeButton.setLayoutParams(lp);
            closeButton.setBackgroundColor(0xFFFFFFFF);
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Close the window
                    dismiss();
                }
            });
            Button showControllerButton = new Button(context);
            showControllerButton.setText("Show Controller");
            showControllerButton.setTypeface(closeButton.getTypeface(), Typeface.BOLD_ITALIC);
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp2.gravity = Gravity.RIGHT;
            showControllerButton.setLayoutParams(lp2);
            showControllerButton.setBackgroundColor(0xFFFFFFFF);
            showControllerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mediaController!=null)
                        mediaController.show();
                }
            });
            // Generate the layout
            layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
            // layoutParams.setMargins(50,15,50,0);
            layout.setLayoutParams(layoutParams);
            // layout.addView(closeButton);
            /*
            if (!internetAvailable(context)) {
                TextView tv = new TextView(context);
                tv.setText("No network available");
                tv.setTypeface(Typeface.DEFAULT_BOLD);
                tv.setTextSize(30);
                layout.addView(tv);
            }
            */
            layout.addView(videoView);
            // layout.addView(showControllerButton);
            setContentView(layout);
            setFocusable(true);
            videoView.start();
            videoView.requestFocus();
        }

        /** Display the PopupWindow at a specific location with a specific size.
         *
         * @param left X coordinate of the top left corner
         * @param top Y coordinate of the top left corner
         * @param width Width of the window
         * @param height Height of the window
         */

        public void show(int left, int top, int width, int height) {
            int orientation = context.getResources().getConfiguration().orientation;
            if (orientation == Configuration.ORIENTATION_PORTRAIT)
                showBigToast(context, "Videos are best viewed in landscape mode.", Gravity.CENTER);
            showAtLocation(layout, Gravity.TOP|Gravity.LEFT, left, top);
            update(left,top,width,height);
        }

        /**
         * Display the PopupWindow at a standard location with a standard size.
         */

        public void show() {
            final int left = 20;
            final int top = 10;
            show(left,top,Resources.getSystem().getDisplayMetrics().widthPixels-left,Resources.getSystem().getDisplayMetrics().heightPixels-top);
        }

    }

    static void showBigToast(Context context, String text) {
        showBigToast(context,text,Gravity.TOP);
    }

    static void showBigToast(Context context, String text, int gravity) {
        Toast toast = Toast.makeText(context,text,Toast.LENGTH_SHORT);
        ViewGroup toastView = (ViewGroup)toast.getView();
        TextView tv = (TextView)toastView.getChildAt(0);
        tv.setTextSize(30);
        tv.setTextColor(Color.BLACK);
        tv.setBackgroundColor(Color.WHITE);
        toastView.setBackgroundColor(Color.WHITE);
        toastView.setAlpha(.8f);
        toast.setGravity(gravity,0,0);
        toast.show();
    }

    static void setMenuFont(Menu menu) {
        // https://stackoverflow.com/questions/29844064/how-to-change-the-menu-text-size/29844361
        for(int i=0; i<menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString spanString = new SpannableString(menu.getItem(i).getTitle().toString());
            int end = spanString.length();
            spanString.setSpan(new RelativeSizeSpan(1.5f), 0, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            item.setTitle(spanString);
        }

    }

    static boolean internetAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return (connectivityManager.getActiveNetworkInfo() != null
                && connectivityManager.getActiveNetworkInfo().isAvailable()
                && connectivityManager.getActiveNetworkInfo().isConnected());
    }

}
