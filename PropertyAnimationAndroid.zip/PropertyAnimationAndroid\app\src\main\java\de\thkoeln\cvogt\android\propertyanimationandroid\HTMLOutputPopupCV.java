package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

/** Popup window to display a HTML formatted text.
 */

public class HTMLOutputPopupCV extends PopupWindow {

    LinearLayout layout;

    /** Constructor
     *
     * @param context Context (= activity) using this popup window
     * @param htmlString HTML formatted text to be displayed.
     */

    public HTMLOutputPopupCV(final Context context, final String htmlString) {
        super(context);
        // Generate a WebView
        final WebView webView = new WebView(context);
        // To load everything into the WebView, i.e. never call an external browser as e.g. Firefox:
        webView.setWebViewClient(
                new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        view.loadUrl(url);
                        return true;
                    }
                });
        // To allow zooming with a two-finger gesture
        WebSettings webSettings = webView.getSettings();
        webSettings.setDisplayZoomControls(false);
        webSettings.setBuiltInZoomControls(true);
        // Generate a button to close the window
        Button closeButton = new Button(context);
        closeButton.setText("Close");
        closeButton.setTypeface(closeButton.getTypeface(), Typeface.BOLD_ITALIC);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.RIGHT;
        // lp.rightMargin = -80;
        // lp.topMargin = -60;
        closeButton.setLayoutParams(lp);
        closeButton.setBackgroundColor(0xFFFFFFFF);
        // closeButton.setTextSize(textSize);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Close the window
                dismiss();
            }
        });
        // Generate the layout
        // layout = new FrameLayout(context);
        layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.setMargins(50,15,50,0);
        layout.setLayoutParams(layoutParams);
        layout.addView(closeButton);
        layout.addView(webView);
        setContentView(layout);
        setFocusable(true);
        webView.loadData(htmlString,"text/html","utf-8");
    }

    /** Display the PopupWindow at a specific location with a specific size.
     *
     * @param top X coordinate of the top left corner
     * @param left Y coordinate of the top left corner
     * @param width Width of the window
     * @param height Height of the window
     */

    public void show(int top, int left, int width, int height) {
        showAtLocation(layout, Gravity.TOP| Gravity.LEFT, top, left);
        update(top,left,width,height);
    }

    /**
     * Display the PopupWindow at a standard location with a standard size.
     */

    public void show() {
        final int top = 100;
        final int left = 20;
        show(top,left, Resources.getSystem().getDisplayMetrics().widthPixels-left,-1);
    }

}