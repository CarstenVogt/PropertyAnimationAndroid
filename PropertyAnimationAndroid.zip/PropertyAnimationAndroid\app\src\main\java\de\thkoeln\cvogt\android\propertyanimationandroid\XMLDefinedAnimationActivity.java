package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 2.9.2019

// This activity demonstrates how to specify an animation through XML code (see res/animator/pos_and_size_animator.xml and android.animation.AnimatorInflater;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

public class XMLDefinedAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_defined_animation);

    }

    public void startAnimation(View v) {

        // get the animation specification from an XML file
        AnimatorSet animSet = (AnimatorSet) AnimatorInflater.loadAnimator(this,R.animator.pos_and_size_animator);

        // specify the object to be animated
        TextView animatedView = (TextView) findViewById(R.id.viewMultiAnimText);
        animSet.setTarget(animatedView);

        // start the animation
        animSet.start();

    }

    public void reset(View v) {

        setContentView(R.layout.xml_defined_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - XML-defined animation</H2>\n" +
                "Animations can also be defined in XML, using these elements:" +
                "<UL><LI><font face=\"Courier\">&lt;set&gt;</font> (= animator set)" +
                "<LI><font face=\"Courier\">&lt;objectAnimator&gt;</font>" +
                "<LI><font face=\"Courier\">&lt;valueAnimator&gt;</font> </UL>" +
                "Attributes are e.g.:" +
                "<UL><LI><font face=\"Courier\">propertyName</font>" +
                "<LI><font face=\"Courier\">duration</font>" +
                "<LI><font face=\"Courier\">valueFrom</font>, <font face=\"Courier\">valueTo</font> </UL>" +
                "<B>Programming steps</B><P>" +
                "These are the programming steps when using XML to program an animation:" +
                "<UL><LI>Step 1: Write an XML file in <font face=\"Courier\">res/animator</font><BR>" +
                "Example:<BR>" +
                "<font face=\"Courier\">&lt;set ...<BR>" +
                "&nbsp;android:ordering=\"together\"&gt;<BR>" +
                "&nbsp;&lt;objectAnimator<BR>" +
                "&nbsp;&nbsp;android:propertyName=\"x\"<BR>" +
                "&nbsp;&nbsp;android:duration=\"2000\"<BR>" +
                "&nbsp;&nbsp;android:valueTo=\"350\"<BR>" +
                "&nbsp;&nbsp;android:valueType=\"floatType\"&sol;&gt;<BR>" +
                "&nbsp;&lt;objectAnimator<BR>" +
                "&nbsp;&nbsp;android:propertyName=\"y\"<BR>" +
                "&nbsp;&nbsp;...&gt;<BR>" +
                "&nbsp;...<BR>" +
                "&nbsp;&gt;<P></font>" +
                "<LI>Step 2: Create an animator set from the XML file<BR>" +
                "<font face=\"Courier\">AnimatorSet animSet =<BR>&nbsp;(AnimatorSet)<BR>" +
                "&nbsp;AnimatorInflater.loadAnimator(<BR>" +
                "&nbsp;&nbsp;...,R.animator.myXmlFile);</font><P>" +
                "<LI>Step 3: Connect the animator set with the animated view<BR>" +
                "<font face=\"Courier\">animSet.setTarget(animatedView);</font><P>" +
                "<LI>Step 4: Start the animation<BR>" +
                "<font face=\"Courier\">animSet.start();</font></UL>";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_XMLAnimation_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_xmlanimation+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#declaring-xml")).show();
    }

}
