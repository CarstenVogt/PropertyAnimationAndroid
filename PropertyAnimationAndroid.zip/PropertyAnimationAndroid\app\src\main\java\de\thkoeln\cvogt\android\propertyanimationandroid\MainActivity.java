package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 08.07.2019

// This app demonstrates various techniques for "property animation", i.e. to animate the properties of View objects

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends ListActivityTwoLineItemsCV {

    @Override
    protected String[] titles() {
        String[] itemTitles = { "Android Property Animation: Introduction",
                "ViewPropertyAnimator", "ObjectAnimator: Single Property", "ObjectAnimator: Multiple Properties",
                "ObjectAnimator: Non-Constant Speed", "ObjectAnimator: Self-Defined Timing", "ObjectAnimator: Non-Linear Animation",
                "ValueAnimator", "XML-defined Animation", "Application: Hide And Reveal", "Application: Non-Numerical Properties" };
        return itemTitles;
    }

    @Override
    protected String[] longtexts() {
        String[] longtexts = {
                "A short introduction to Android property animation",
                "Animation by the View method animate()",
                "Animation of single object properties",
                "Animation of multiple properties of the same object",
                "Animation of a movement with a timing specified by predefined TimeEvaluators",
                "Animation of a movement with a timing specified by the programmer",
                "Animation of a non-linear value change",
                "Animation with an AnimatorUpdateListener, i.e. update operations specified by the programmer",
                "Animation defined by XML code",
                "Property animation used to add and remove views",
                "Property animation of a view's font, i.e. of a property that has no numeric value",
        };
        return longtexts;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startActivity (new Intent(this, TitleAnimation.class));

        // Utils.showBigToast(this,"Android Property Animation", Gravity.CENTER);
        /*
        Toast t = new Toast(this);
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.introtoastlayout, (ViewGroup) findViewById(R.id.IntroToastLayout));
        t.setView(layout);
        t.setGravity(Gravity.CENTER,0,0);
        t.setDuration(Toast.LENGTH_LONG);
        t.show();
        */
    }

    protected void onListItemClick(ListView liste, View datenElement, int position, long id) {
        super.onListItemClick(liste, datenElement, position, id);
        switch(position) {
            case 0: startActivity(new Intent(this, IntroActivity.class)); break;
            case 1: startActivity(new Intent(this, ViewPropertyAnimatorActivity.class)); break;
            case 2: startActivity(new Intent(this, SinglePropertyAnimationActivity.class)); break;
            case 3: startActivity(new Intent(this, MultiplePropertiesAnimationActivity.class)); break;
            case 4: startActivity(new Intent(this, NonConstantSpeedAnimationActivity.class)); break;
            case 5: startActivity(new Intent(this, SelfDefinedTimingAnimationActivity.class)); break;
            case 6: startActivity(new Intent(this, NonLinearValuesAnimationActivity.class)); break;
            case 7: startActivity(new Intent(this, ValueAnimatorAnimationActivity.class)); break;
            case 8: startActivity(new Intent(this, XMLDefinedAnimationActivity.class)); break;
            case 9: startActivity(new Intent(this, HideRevealAnimationActivity.class)); break;
            case 10: startActivity(new Intent(this, NonNumericalValuesAnimationActivity.class)); break;
        }
    }
    
}



