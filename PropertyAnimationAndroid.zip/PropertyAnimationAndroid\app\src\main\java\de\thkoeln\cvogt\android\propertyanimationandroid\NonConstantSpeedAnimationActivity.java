package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 15.11.2017

// This activity demonstrates the animation of views with varying speeds and timing behaviors

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.animation.ObjectAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.PopupMenu;
import android.widget.TextView;


public class NonConstantSpeedAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.nonconstant_speed_animation);

    }

    public void startAnimation(View v) {

        int duration = 5000; // duration of the animation
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        float endY = 3*screenHeight/4;

        TextView animatedViews[] = new TextView[8];
        animatedViews[0] = (TextView) findViewById(R.id.animview0);
        animatedViews[1] = (TextView) findViewById(R.id.animview1);
        animatedViews[2] = (TextView) findViewById(R.id.animview2);
        animatedViews[3] = (TextView) findViewById(R.id.animview3);
        animatedViews[4] = (TextView) findViewById(R.id.animview4);
        animatedViews[5] = (TextView) findViewById(R.id.animview5);
        animatedViews[6] = (TextView) findViewById(R.id.animview6);
        animatedViews[7] = (TextView) findViewById(R.id.animview7);

        // generate ObjectAnimators to control the animations: movement into the y direction

        ObjectAnimator objectAnimators[] = new ObjectAnimator[animatedViews.length];
        for (int i=0;i<objectAnimators.length;i++) {
            objectAnimators[i] = ObjectAnimator.ofFloat(animatedViews[i], "y", endY);
            objectAnimators[i].setDuration(duration);
        }

        // set TimeInterpolators to control the timing of the animations:
        //   different TimeInterpolators lead to different timing behaviors
        //   (for a detailed explanation of interpolators, see SelfDefinedTimingAnimationActivity.java)

        objectAnimators[0].setInterpolator(new AccelerateInterpolator());
        objectAnimators[1].setInterpolator(new AccelerateDecelerateInterpolator());
        objectAnimators[2].setInterpolator(new DecelerateInterpolator());

        objectAnimators[3].setInterpolator(new AnticipateInterpolator());
        objectAnimators[4].setInterpolator(new AnticipateOvershootInterpolator());
        objectAnimators[5].setInterpolator(new OvershootInterpolator());
        objectAnimators[6].setInterpolator(new BounceInterpolator());

        objectAnimators[7].setInterpolator(new CycleInterpolator(3));

        // start the animations

        for (int i=0;i<objectAnimators.length;i++)
           objectAnimators[i].start();

    }

    public void reset(View v) {

        setContentView(R.layout.nonconstant_speed_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - Timing Behaviour (1)</H2>\n" +
                "In the default case, an animation plays at constant speed. " +
                "As an alternative, the programmer can use <font face=\"Courier\">TimeInterpolator</font> objects " +
                "e.g. to accelerate or decelerate the animation speed. " +
                "A time interpolator is set by:<P>" +
                "<font face=\"Courier\">myObjectAnimator.<BR>" +
                "&nbsp;&nbsp;&nbsp;setInterpolator(<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myTimeInterpolator)</font><P>" +
                "Android provides some subclasses of <font face=\"Courier\">TimeInterpolator</font>:<UL>" +
                "<LI><font face=\"Courier\">AccelerateInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Increase speed" +
                "<LI><font face=\"Courier\">DecelerateInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Decrease speed" +
                "<LI><font face=\"Courier\">AccelerateDecelerateInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Combination of both" +
                "<LI><font face=\"Courier\">OvershootInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Overshoot the target" +
                "<LI><font face=\"Courier\">AnticipateInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Retract from the start" +
                "<LI><font face=\"Courier\">AnticipateOvershootInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Combination of both" +
                "<LI><font face=\"Courier\">BounceInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Bounce at the target" +
                "<LI><font face=\"Courier\">CycleInterpolator</font>:<BR>&nbsp;&nbsp;&nbsp;&nbsp;Repeat for a number of cycles" +
                "<LI>and others</UL>" +
                "The next section will show you how to write your own time interpolators.";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_Timing1_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_objectanimator_timing1+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/animation/TimeInterpolator.html")).show();
    }

}
