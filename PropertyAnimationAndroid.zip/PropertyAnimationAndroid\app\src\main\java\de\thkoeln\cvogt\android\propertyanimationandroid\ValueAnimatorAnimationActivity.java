package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 6.9.2019

// This activity demonstrates how to animate an object property through a ValueAnimator and its update listener.
// A ValueAnimator is a generalization of an ObjectAnimator because the update listener,
// which is called in each animation step and assigns property values, can be freely programmed.
// The actions performed in each animation step are therefore under full control of the programmer.

import android.animation.FloatEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.PopupMenu;
import android.widget.TextView;

public class ValueAnimatorAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.value_animator_animation);
    }

    public void startAnimation(View v) {

        int duration = 2000;  // duration of the animation in ms

        // get a reference for the animated view
        TextView animatedView = (TextView) findViewById(R.id.valanim_animatedview);

        // create a ValueAnimator to control the animation
        ValueAnimator animator = new ValueAnimator();

        // set its TimeInterpolator to map the real time axis to a virtual time axis,
        //  thus "stretching" or "compressing" the time axis (see SelfDefinedTimingAnimation.java for a detailed explanation)
        animator.setInterpolator(new AccelerateDecelerateInterpolator());

        // set its evaluator to calculate the object property values from the virtual time values
        // (here: a standard FloatEvaluator for a simple linear calculation)
        animator.setEvaluator(new FloatEvaluator());

        // set the update listener to modify the animated object's property for each animation step
        // and perform some additional operations (see below)
        animator.addUpdateListener(new MyAnimatorUpdateListener(animatedView.getY()));

        // set start and target values of the animation
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        animator.setFloatValues(animatedView.getY(),screenHeight-300);

        // set the duration of the animation
        animator.setDuration(duration);

        // start the animation
        animator.start();

    }

    public void reset(View v) {

        setContentView(R.layout.value_animator_animation);

    }

    // Update listener:
    // Its callback function onAnimationUpdate() is called each time a new step of the animation shall be displayed (usually every 10 ms).
    // Besides setting the property value, this listener displays the current speed of the animated view on the display.

    class MyAnimatorUpdateListener implements ValueAnimator.AnimatorUpdateListener {

        float prevPos;  // the previous position of the view (for calculating the speed of the view)

        MyAnimatorUpdateListener(float prevPos) {
            this.prevPos = prevPos;
        }

        @Override
        public void onAnimationUpdate(ValueAnimator animator) {

            // calculate the new value for the animated property
            // (through the animator with its time interpolator and type evaluator)
            float currentPos = (float) animator.getAnimatedValue();

            // set the animated object's property with the new value
            TextView animatedView = (TextView) findViewById(R.id.valanim_animatedview);
            animatedView.setY(currentPos);

            // additional operation: calculate and display the current speed
            int currentSpeed = Math.round(currentPos-prevPos);
            TextView outputSpeed = (TextView) findViewById(R.id.valanim_outputspeed);
            outputSpeed.setText("Speed: "+currentSpeed);

            // prepare the next round
            prevPos = currentPos;

        }

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
            "<H2>Property Animation: ValueAnimator</H2>\n" +
            "<B>Generalizing object animators</B><P>" +
            "Value animators are the most general way to program a property animation. " +
            "The corresponding class <font face=\"Courier\">ValueAnimator</font> " +
            "is the superclass of <font face=\"Courier\">ObjectAnimator</font>. " +
            "A value animator can (in the same way as an object animator) be connected with a time interpolator " +
            "and a type evaluator to specify the timing of the animation and the calculation " +
            "of the property values, respectively.<P>" +
            "Additionally, a value animator has an <I>update listener</I> with a callback method " +
            "<font face=\"Courier\">onAnimationUpdate()</font>. " +
            "This method is called by the runtime system for each animation step. " +
            "By writing the code for this method, the programmer has full control of what happens in a step.<P>" +
            "<B>Programming steps</B><P>" +
            "These are the programming steps when using a value animator:" +
            "<UL><LI>Step 1: Implement the <font face=\"Courier\">AnimatorUpdateListener</font> interface<BR>" +
            "<font face=\"Courier\">class MyAnimatorUpdateListener<BR>" +
            "&nbsp;implements ValueAnimator.AnimatorUpdateListener {<BR>" +
            "&nbsp;&nbsp;public void<BR>&nbsp;&nbsp;onAnimationUpdate(<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;ValueAnimator animator) {<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;propValue = " +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;animator.getAnimatedValue();<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myAnimatedView.setXXX(<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;propValue);<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<I>... additional<BR>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;operations ...</I> }<BR>" +
            "}</font><BR>" +
            "Note: The update listener explicitly assigns the property value and " +
            "may perform additional operations, e.g. outputs on the display.<P>" +
            "<LI>Step 2: Create a value animator and assign the update listener<BR>" +
            "<font face=\"Courier\">ValueAnimator myValAnim<BR>= new ValueAnimator();<BR>" +
            "myValAnim.addUpdateListener(<BR>" +
            "&nbsp;&nbsp;new MyAnimatorUpdateListener());</font)<P>" +
            "<LI>Step 3: Start the animation<BR>" +
            "<font face=\"Courier\">myObjAnim.setDuration(...);<BR>" +
            "myObjAnim.start();</font></UL>";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ValueAnimator_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_valueanimator+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#value-animator")).show();
    }

}

/*

Old version

import android.animation.TimeInterpolator;
        import android.animation.TypeEvaluator;
        import android.animation.ValueAnimator;
        import android.app.Activity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.PopupMenu;
        import android.widget.TextView;

public class ValueAnimatorAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.value_animator_animation_alt);
    }

    public void startAnimation(View v) {

        int duration = 2000;  // duration of the animation in ms
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        // create a ValueAnimator to control the animation
        ValueAnimator animator = new ValueAnimator();

        // set its TimeInterpolator to map the real time axis to a virtual time axis,
        //  thus "stretching" or "compressing" the time axis (see SelfDefinedTimingAnimation.java for a detailed explanation)
        animator.setInterpolator(new MyTimeInterpolator());

        // set its evaluator to calculate the object property values from the virtual time values
        animator.setEvaluator(new MyFloatEvaluator());
        // alternative: set the evaluator when creating the animator through a static factory method - ValueAnimator.ofObject(typeEvaluator,startValue,targetValue)

        // set the update listener to modify the animated object's property for each animation step
        animator.addUpdateListener(new MyAnimatorUpdateListener());

        // set start and target values of the animation
        TextView animatedView = (TextView) findViewById(R.id.view20);
        animator.setFloatValues(animatedView.getY(),screenHeight-100);
        // alternative: set these values when creating the animator through a static factory method - ValueAnimator.ofFloat(startValue,targetValue)

        // set the duration of the animation
        animator.setDuration(duration);

        // start the animation
        animator.start();

    }

    public void reset(View v) {

        setContentView(R.layout.value_animator_animation);

    }

    // Listener: Its callback function onAnimationUpdate() is called each time a new step of the animation shall be displayed
    //           (normally every 10 ms).

    class MyAnimatorUpdateListener implements ValueAnimator.AnimatorUpdateListener {

        @Override
        public void onAnimationUpdate(ValueAnimator animator) {

            Log.v("DEMO", "onAnimationUpdate()");

            // calculate new value for the animated property
            float currentPosition = (float) animator.getAnimatedValue();

            // set the animated object's property to the new value
            TextView animatedView = (TextView) findViewById(R.id.view20);
            animatedView.setY(currentPosition);

            // refresh the display
            animatedView.invalidate();

        }

    }

    // The evaluator calculates the current value of the property to be animated,
    //   taking into account the current progress of the animation (given by a fraction parameter between 0.0 and 1.0).
    // (This class is included only for instructional purposes here; it has the same effect as the predefined class FloatEvaluator.)

    class MyFloatEvaluator implements TypeEvaluator<Float> {

        @Override
        public Float evaluate(float fraction, Float startValue, Float endValue) {

            Log.v("DEMO", "evaluate()");

            // linear interpolation between start and end value
            return (startValue.floatValue() + fraction * (endValue.floatValue() - startValue.floatValue()));

        }

    }

    // The time interpolator maps real time values to virtual time values, which are then fed into the Evaluator function evaluate().
    // (For a detailed comment on time interpolators, see SelfDefinedTimingAnimation.java.)

    class MyTimeInterpolator implements TimeInterpolator {

        @Override
        public float getInterpolation(float input) {

            // The virtual time is calculated as the real time raised to the power of four and will hence be smaller than the real time
            // as long as input<1.0. Therefore, this simple calculation has the effect that the animation starts slower
            // than an animation with constant speed and will then catch up.

            return input*input*input*input;

        }

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ValueAnimator</H2>\n" +
                        "Not yet available";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        Utils.showBigToast(this,"Not yet available");
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_Timing2_480.mp4")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#value-animator")).show();
    }

}

*/
