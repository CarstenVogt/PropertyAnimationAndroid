package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 15.11.2017

// This activity demonstrates how to animate a property with a type other that int, float, or color.

import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

public class NonNumericalValuesAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nonnumerical_values_animation);
    }

    public void startAnimation(View v) {

        int duration = 6000;  // duration of the animation in ms

        // Animate the font of a TextView object on the display.
        // The font to be shown in the course of the animation is "calculated" by an evaluator (see class MyTypefaceEvaluator below).
        // It is then fed automatically into the setTypeface() method of the animated object (as specified by the parameter "typeface").

        TextView animatedView = (TextView) findViewById(R.id.view11);
        Typeface startValue =  Typeface.create("Arial", Typeface.NORMAL);

        ObjectAnimator anim = ObjectAnimator.ofObject(animatedView, "typeface", new MyTypefaceEvaluator(), startValue);

        anim.setDuration(duration);
        anim.start();

    }

    public void reset(View v) {

        setContentView(R.layout.nonnumerical_values_animation);

    }

    // The evaluator tells the animator which font to display.
    // This font is "calculated" by the evaluate() method, taking into account the current progress of the animation
    // (as given by a 'fraction' parameter between 0.0 and 1.0 that specifies how much of the animation time has already passed).

    class MyTypefaceEvaluator implements TypeEvaluator<Typeface> {

        @Override
        public Typeface evaluate(float fraction, Typeface startValue, Typeface endValue) {

            if (fraction < 0.25) return startValue;                                 // Font to be displayed during the first quarter of the animation

            if (fraction < 0.5)  return Typeface.create("Arial", Typeface.BOLD);    // Font to be displayed during the second quarter of the animation

            if (fraction < 0.75) return Typeface.create("Arial", Typeface.ITALIC);  // Font to be displayed during the third quarter of the animation

            return Typeface.create("Arial", Typeface.BOLD_ITALIC);                  // Font to be displayed during the last quarter of the animation

        }

    }

}


