package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 07.08.2019

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class IntroActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.overview);
    }

    String videoFilename = R.raw.propanim_intro+"";
    // String videoURL = "http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_Intro_480.mp4";

    String webPageURL = "https://developer.android.com/guide/topics/graphics/prop-animation";

    String explanation = "<H2>Property Animation in Android</H2>\n" +
            "Objects have properties (aka attributes, members, or fields) to store values. " +
            "These values can be changed by calling setter methods with corresponding parameters. " +
            "Each <font face=\"Courier\">View</font> object e.g. has its <font face=\"Courier\">x</font> and <font face=\"Courier\">y</font> properties, " +
            "which specify its position on the display and can be modified by calling " +
            "<font face=\"Courier\">setX()</font> and <font face=\"Courier\">setY()</font>, respectively.<P>" +
            "In a property animation, such setter methods are called repeatedly over a specified time period with changing parameter values. " +
            "For a <font face=\"Courier\">View</font> object e.g. it might be that <font face=\"Courier\">setX()</font> is called over and over again " +
            "during a period of <I>n</I> seconds " +
            "while changing the <font face=\"Courier\">x</font> property incrementally from its start value to an end value. " +
            "This will effect a linear movement of the view on the display.<P>" +
            "To program a property animation, the Android programmer must only provide some fundamental information " +
            "like the name of the property to be animated, the start and the end value of the animation, its duration " +
            "and its timing behaviour. The setters will then be called automatically by the Android runtime system.";

    public void showText(View v) {
        (new Utils.HTMLOutputPopup(this,explanation)).show();
    }

    public void showVideo(View v) {
        // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        (new Utils.VideooutputPopup(v.getContext(),videoFilename)).show();
    }

    public void showWebPage(View v) {
        (new Utils.WebViewPopup(this,webPageURL)).show();
    }

    public void showOverviewVideo(View v) {
        String urlString = "";
        switch (v.getId()) {
            case R.id.but_overviewvideo1: urlString = "http://youtu.be/mym1hApcJG4"; break;
            case R.id.but_overviewvideo2: urlString = "http://youtu.be/FmOdxHkGPus"; break;
            case R.id.but_overviewvideo3: urlString = "http://youtu.be/Rk3DzpNsTMw"; break;
        }
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlString));
        startActivity(browserIntent);
    }

}
