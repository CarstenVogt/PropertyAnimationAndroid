package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 15.11.2017

// This activity demonstrates how to use ObjectAnimators to animate various single properties of a view with constant speed.

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.animation.ObjectAnimator;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class SinglePropertyAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_property_animation);

    }

    public void startAnimation(View v) {

        int duration = 1500;  // duration of the animation in ms
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        // animate movement into x direction
        TextView animatedView1 = (TextView) findViewById(R.id.view1);
        float endX = screenWidth - animatedView1.getWidth() - 100;  // target x position of the object
        ObjectAnimator animX = ObjectAnimator.ofFloat(animatedView1, "x", endX);
               // ObjectAnimator to animate the x position of the object
               // ("x" = the animator shall call the "setX()" method of the animated object to modify its properties)
        animX.setDuration(duration);
        animX.start();

        // animate movement into y direction
        TextView animatedView2 = (TextView) findViewById(R.id.view2);
        float endY = screenHeight - animatedView2.getHeight() - 250;  // target y position of the object
        ObjectAnimator animY = ObjectAnimator.ofFloat(animatedView2, "y", endY);
               // ObjectAnimator to animate the y position of the object
               // ("y" = the animator shall call the "setY()" method of the animated object to modify its properties)
        animY.setDuration(duration);
        animY.start();

        // scale
        TextView animatedView3 = (TextView) findViewById(R.id.view3);
        float endSize = 2.0f;  // target size of the object (i.e. double)
        ObjectAnimator animSizeX = ObjectAnimator.ofFloat(animatedView3, "scaleX", endSize);
               // ObjectAnimator to animate the x scale factor of the object
               // ("scaleX" = the animator shall call the "setScaleX()" method of the animated object to modify its properties)
        animSizeX.setDuration(duration);
        animSizeX.setRepeatCount(3);  // repeat the scaling three times ...
        animSizeX.setRepeatMode(ObjectAnimator.REVERSE); // ... and also backwards, i.e. let the object grow and shrink
        animSizeX.start();

        // alternative: scale text size
        // TextView animatedView3 = (TextView) findViewById(R.id.view3);
        // float endSize = animatedView3.getTextSize()+20;
        // ObjectAnimator animSize = ObjectAnimator.ofFloat(animatedView3, "textSize", endSize);
        // animSize.setDuration(duration);
        // animSize.start();

        // rotate
        TextView animatedView4 = (TextView) findViewById(R.id.view4);
        ObjectAnimator animRot = ObjectAnimator.ofFloat(animatedView4, "rotation", 360);
               // ObjectAnimator to rotate the object
               // ("rotation" = the animator shall call the "setRotation()" method of the animated object to modify its properties)
        animRot.setDuration(duration);
        animRot.setRepeatCount(3);  // repeat the rotation three times
        animRot.start();

        // fade
        TextView animatedView5 = (TextView) findViewById(R.id.view5a);
        ObjectAnimator animFade = ObjectAnimator.ofFloat(animatedView5, "alpha", 0);
               // ObjectAnimator to let the object vanish
               // ("alpha" = the animator shall call the "setAlpha()" method of the animated object to modify its properties)
        animFade.setDuration(duration);
        animFade.start();

        // animate color
        LinearLayout animatedView6 = (LinearLayout) findViewById(R.id.layout);
        int colorFrom = Color.WHITE;  // initial color
        int colorTo = Color.YELLOW;   // target color
        ObjectAnimator animCol = ObjectAnimator.ofInt(animatedView6, "backgroundColor", colorFrom, colorTo);
               // ObjectAnimator to let the object vanish
               // ("backgroundColor" = the animator shall call the "setBackgroundColor()" method of the animated object to modify its properties)
        animCol.setDuration(2*duration);
        animCol.setRepeatCount(1);  // repeat the animation once ...
        animCol.setRepeatMode(ObjectAnimator.REVERSE);  // ... backwards, i.e. the screen is white again at the end
        animCol.start();

    }

    public void reset(View v) {

        setContentView(R.layout.single_property_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - Basics</H2>" +
                "The class <font face=\"Courier\">ObjectAnimator</font> provides a very flexible way to animate <font face=\"Courier\">View</font> objects.<P>" +
                "<B>Creation through factory methods</B><P>" +
                "<font face=\"Courier\">ObjectAnimator</font> objects are created through static factory methods of this class. " +
                "The call<BR><font face=\"Courier\">ObjectAnimator.<BR>&nbsp;&nbsp;&nbsp;ofFloat(myView,\"x\",500)</font>,<BR>e.g., " +
                "creates an animator for the object <font face=\"Courier\">myView</font> that animates its <font face=\"Courier\">x</font> property with target value 500.<P>" +
                "The general form of a factory method is:<P>" +
                "<font face=\"Courier\">ObjectAnimator.of<I>TYPE</I>(<BR>" +
                "&nbsp;&nbsp;&nbsp;<I>ANIMATED_OBJECT</I>,<BR>" +
                "&nbsp;&nbsp;&nbsp;<I>PROPERTY_NAME</I>,<BR>" +
                "&nbsp;&nbsp;&nbsp;<I>VALUES</I>)</font>,<P>" +
                "<UL><LI>where <font face=\"Courier\">TYPE</font> = <font face=\"Courier\">Argb</font>, <font face=\"Courier\">Int</font>, <font face=\"Courier\">Float</font>, " +
                "<font face=\"Courier\">MultiInt</font>, <font face=\"Courier\">MultiFloat</font>, or <font face=\"Courier\">Object</font>. " +
                "<font face=\"Courier\">MultiInt</font> and <font face=\"Courier\">MultiFloat</font> are used for setters with multiple parameters, " +
                "<font face=\"Courier\">Object</font> is used for setters with parameters of class <font face=\"Courier\">Object</font>.<P>" +
                "<LI><font face=\"Courier\">VALUES</font> stands for one or multiple values of type <font face=\"Courier\"><I>TYPE</I></font> " +
                "- in case of one value it is the end value, " +
                "in case of multiple values it is the start value, possibly intermediate values, and the end value.</UL>" +
                "There exist factory methods with two <font face=\"Courier\"><I>PROPERTY_NAME</I></font> parameters. " +
                "They are usually called with the <font face=\"Courier\">x</font> and <font face=\"Courier\">y</font> properties " +
                "to animate the position of a <font face=\"Courier\">View</font> object. " +
                "Some factory methods accept <font face=\"Courier\">Path</font> objects as <font face=\"Courier\"><I>VALUES</I></font> parameters " +
                "to animate a movement along a geometric path.<P>" +
                "<B>Further specification through setter methods</B><P>" +
                "Setter methods are used to specify more details of the animation, as e.g. " +
                "<font face=\"Courier\">setDuration()</font>, <font face=\"Courier\">setStartDelay()</font>, and <font face=\"Courier\">setRepeatCount()</font>.<P>" +
                "<B>Programming steps</B><P>" +
                "These are the programming steps when using an object animator to animate a single object:" +
                "<UL><LI>Step 1: Create an <font face=\"Courier\">ObjectAnimator</font> object<BR>" +
                "<font face=\"Courier\">ObjectAnimator myAnimator<BR>" +
                "&nbsp;&nbsp;&nbsp;= ObjectAnimator.ofXXX(<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myAnimatedObject,<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\"PropertyName\",<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myAnimationValues);</font><P>" +
                "<LI>Step 2: Specify details of the animation<BR>" +
                "<font face=\"Courier\">myAnimator.setDuration(...);</font><BR>" +
                "<font face=\"Courier\">myAnimator.setStartDelay(...);</font><BR>" +
                "<font face=\"Courier\">...</font><P>" +
                "<LI>Step 3: Start the animation<BR>" +
                "<font face=\"Courier\">myAnimator.start();</font></UL>" +
                "<B>Example code</B><P>" +
                "The code for the uppermost view in the demo app is this:<P>" +
                "<font face=\"Courier\">View view1 = (TextView)<BR>" +
                "&nbsp;&nbsp;&nbsp;findViewById(R.id.view1);<BR>" +
                "float endX = screenWidth-300;<BR>" +
                "ObjectAnimator animX =<BR>" +
                "&nbsp;&nbsp;&nbsp;ObjectAnimator.ofFloat(<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;view1,\"x\",endX);<BR>" +
                "animX.setDuration(duration);<BR>" +
                "animX.start();</font><P>" +
                "<B>Value calculation and timing behaviour</B><P>" +
                "The values for the animated property are usually calculated by a linear interpolation " +
                "between start and end values (and possibly intermediate values). " +
                "As an alternative, a <font face=\"Courier\">TypeEvaluator</font> object can be used " +
                "that can return any sequence of animation values.<P>" +
                "The animation proceeds in the normal case with a constant speed. " +
                "As an alternative, a <font face=\"Courier\">TimeInterpolator</font> object can be used " +
                "e.g. to speed up and/or slow down the animation.<P>" +
                "Details on type evaluators and time evaluators will follow.<P>";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_Basics_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_objectanimator_basics+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/animation/ObjectAnimator.html")).show();
    }

}
