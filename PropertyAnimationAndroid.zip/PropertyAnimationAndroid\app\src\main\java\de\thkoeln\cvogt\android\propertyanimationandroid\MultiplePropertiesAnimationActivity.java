package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 4.8.2019

// This activity demonstrates how to animate multiple properties of a view with constant speed:
// 1.) by AnimatorSets that comprise multiple ObjectAnimators to animate any combination of properties
// 2.) by Paths to animation the x and y properties together, i.e. the position of the object

import android.animation.AnimatorSet;
import android.app.Activity;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.animation.ObjectAnimator;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;


public class MultiplePropertiesAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.multiple_properties_animation);

    }

    public void startAnimation(View v) {

        animation1(0,4000);
        animation2(8000,12000);

    }

    public void animation1(int startDelay, int duration) {

        int screenWidth = getResources().getDisplayMetrics().widthPixels,
            screenHeight = getResources().getDisplayMetrics().heightPixels;

        // View to be animated

        TextView animView = (TextView) findViewById(R.id.viewMultiAnimText);

        // values for the animation

        float endX = screenWidth - animView.getWidth() - 150,
              endX_2 = screenWidth/2,
              endY = screenHeight - animView.getHeight() - 180,
              endY_2 = 400,
              endScaleX = 2.0f,
              endScaleX_2 = 4.0f,
              endScaleY = 5.0f,
              endAngle = 90.0f,
              endAngle_2 = 180.0f;

        // define five animators: two for the x and y positions,
        // two for the x and y scale factors and one for the rotation.

        ObjectAnimator animX      = ObjectAnimator.ofFloat(animView, "x", endX),
                       animY      = ObjectAnimator.ofFloat(animView, "y", endY),
                       animScaleX = ObjectAnimator.ofFloat(animView, "scaleX", endScaleX),
                       animScaleY = ObjectAnimator.ofFloat(animView, "scaleY", endScaleY),
                       animRot    = ObjectAnimator.ofFloat(animView, "rotation", endAngle);

        // combine the animators in an a animator set to be played together

        AnimatorSet animSet1 = new AnimatorSet();
        animSet1.playTogether(animX,animY,animScaleX,animScaleY,animRot);

        // define four more animators

        ObjectAnimator animX_2      = ObjectAnimator.ofFloat(animView, "x", endX_2),
                       animY_2      = ObjectAnimator.ofFloat(animView, "y", endY_2),
                       animScaleX_2 = ObjectAnimator.ofFloat(animView, "scaleX", endScaleX_2),
                       animRot_2    = ObjectAnimator.ofFloat(animView, "rotation", endAngle_2);

        // combine also these animators in an animator set to be played together

        AnimatorSet animSet2 = new AnimatorSet();
        animSet2.playTogether(animX_2,animY_2,animScaleX_2,animRot_2);

        // combine the two animator sets in a third set to be played sequentially

        AnimatorSet animSetAll = new AnimatorSet();
        animSetAll.playSequentially(animSet1,animSet2);

        // set start delay and duration of the whole animation and start it

        animSetAll.setStartDelay(startDelay);
        animSetAll.setDuration(duration);
        animSetAll.start();

    }

    public void animation2(int startDelay, int duration) {

        int screenWidth = getResources().getDisplayMetrics().widthPixels,
            screenHeight = getResources().getDisplayMetrics().heightPixels;

        // View to be animated

        ImageView animView = (ImageView) findViewById(R.id.viewMultiAnimIcon);

        // define the geometric path for moving the object

        Path path = new Path();

        path.moveTo(animView.getX(),animView.getY());
        path.lineTo(3*screenWidth/4,screenHeight/2);
        path.addCircle(screenWidth/2,screenHeight/2,screenWidth/4,Path.Direction.CW);
        path.cubicTo(screenWidth/2,3*screenHeight/2,screenWidth/4,-screenHeight,100,3*screenHeight/4);

        // define, with the path, the animator to animate the x and y properties, i.e. the position of the object

        ObjectAnimator animXY = ObjectAnimator.ofFloat(animView, "x", "y", path);

        // set start delay and duration of the animation and start it

        animXY.setStartDelay(startDelay);
        animXY.setDuration(duration);
        animXY.start();

    }

    public void reset(View v) {

        setContentView(R.layout.multiple_properties_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain_2,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc_1)
                    explainWithAndroidDocu(1);
                if (item.getItemId()==R.id.menuitem_androiddoc_2)
                    explainWithAndroidDocu(2);
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - MultipleProperties</H2>" +
                "The class <font face=\"Courier\">AnimatorSet</font> allows to combine any number of animations of any type " +
                "to be played together or sequentially. For this purpose it provides the methods<UL>" +
                "<LI><font face=\"Courier\">playTogether(anim1,anim2,...)</font> and" +
                "<LI><font face=\"Courier\">playSequentially(anim1,anim2,...)</font>.</UL>" +
                "With other methods the programmer can<UL>" +
                "<LI>specify the duration of the combined animations (<font face=\"Courier\">setDuration()</font>)" +
                "<LI>a start delay (<font face=\"Courier\">setStartDelay()</font>), and" +
                "<LI>start the animation (<font face=\"Courier\">start()</font>).</UL>" +
                "A special application case is the combined animation of the <font face=\"Courier\">x</font> and the " +
                "<font face=\"Courier\">y</font> properties of an object, i.e. its position. " +
                "This can be done by calling the factory method<P>" +
                "<font face=\"Courier\">ObjectAnimator.ofFloat(<BR>" +
                "&nbsp;&nbsp;<I>ANIMATED_OBJECT</I>,\"x\",\"y\",<I>PATH</I>)</font>,<P>" +
                "where <I>PATH</I> stands for an object of class <font face=\"Courier\">Path</font>. " +
                "It defines a geometric path which can be<BR><UL>" +
                "<LI> a straight line," +
                "<LI> an arc," +
                "<LI> a rectangle," +
                "<LI> a circle," +
                "<LI> an oval," +
                "<LI> a Bezier curve (quadratic or cubic), or" +
                "<LI> consisting of multiple segments of the above types.</UL>";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_MultiProp_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_objectanimator_multiprop+"")).show();
    }

    private void explainWithAndroidDocu(int docNo) {
        Utils.showBigToast(this,"Not yet available");
        switch (docNo) {
            case 1: (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/animation/AnimatorSet.html")).show(); break;
            case 2: (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/animation/ObjectAnimator.html#ofFloat(java.lang.Object,%20java.lang.String,%20java.lang.String,%20android.graphics.Path)")).show(); break;
        }
    }

}
