package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * From this abstract class the programmer can derive ListActivity classes whose items consist of two parts
 * - a "title" (String) with a bigger font size and a "longtext" (String, generally longer than the title) with a smaller font size.
 */

public abstract class ListActivityTwoLineItemsCV extends ListActivity {

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        // The following code is based on https://stackoverflow.com/questions/4837834/2-lines-in-a-listview-item (last code example)
        Intent intent = getIntent();
        String[] titles = titles();
        String[] longtexts = longtexts();
        List<Map<String, String>> listArray = new ArrayList<>();
        for (int i = 0; i < titles.length; i++) {
            Map<String, String> listItem = new HashMap<>();
            listItem.put("titleKey", titles[i]);
            listItem.put("longtextKey", longtexts[i]);
            listArray.add(listItem);
        }
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, listArray,
                android.R.layout.simple_list_item_2,
                new String[]{"titleKey", "longtextKey"},
                new int[]{android.R.id.text1, android.R.id.text2});
        ListView listView = getListView();
        listView.setAdapter(simpleAdapter);
    }

    /**
     * To be overridden - method that returns an array with Strings to be used as item titles.
     * The array must have the same length as the array returned by the method longtexts().
     */

    protected abstract String[] titles();

    /**
     * To be overridden - method that returns an array with Strings to be used as item longtexts.
     * The array must have the same length as the array returned by the method titles().
     */

    protected abstract String[] longtexts();

    /**
     * Listener method for item clicks. Override this method to specify the reactions to item clicks in your derived class.
     * Do not forget to call super.onListItemClick(...) in the overriding method!
     * @param liste as in ListActivity.onListItemClick()
     * @param datenElement as in ListActivity.onListItemClick()
     * @param position as in ListActivity.onListItemClick()
     * @param id as in ListActivity.onListItemClick()
     */

    protected void onListItemClick(ListView liste, View datenElement, int position, long id) {
        super.onListItemClick(liste,datenElement,position,id);
    }

}
