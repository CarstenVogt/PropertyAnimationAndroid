package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 22.7.2019

// This activity demonstrates the animation of a view with a non-linear change of a property value:
// A view is moved along a semicircle:
//
//  S..
//     ..
//       .
//     ..
//  E..
//
// where S is the start position and E is the end position of the view.

import android.animation.TypeEvaluator;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.animation.ObjectAnimator;
import android.widget.PopupMenu;
import android.widget.TextView;


public class NonLinearValuesAnimationActivity extends Activity {

    int radius; // radius of the semicircle

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.nonlinear_values_animation);

        // set the radius such that the semicircle will fit the display
        int displayWidth = getResources().getDisplayMetrics().widthPixels;
        int displayHeight = getResources().getDisplayMetrics().heightPixels;
        radius = displayWidth-200;
        if (radius>(displayHeight/2-200))
            radius = displayHeight/2-200;

    }

    public void startAnimation(View v) {

        int duration = 4000;  // duration of the animation in ms

        TextView animatedView = (TextView) findViewById(R.id.view11);

        MyFloatEvaluator evalX = new MyFloatEvaluator();
                  // evaluator to calculate the values of the x property in the course of the animation - see detailed comments below

        // animator for the x property, calculating the property values with the evaluator 'evalX' of class MyFloatEvaluator defined below
        float endX = animatedView.getX();  // the end x value is the same as the start x value (see sketch of the semicircle above)
        ObjectAnimator animX = ObjectAnimator.ofFloat(animatedView, "x", endX);
        animX.setEvaluator(evalX);

        // animator for the y property, calculating the property values in the standard way (linear interpolation between start and end value)
        float endY = animatedView.getY()+2*radius;   // the end y value is the start y value plus twice the radius (see sketch of the semicircle above)
        ObjectAnimator animY = ObjectAnimator.ofFloat(animatedView, "y", endY);

        animX.setDuration(duration);
        animY.setDuration(duration);
        animX.start();
        animY.start();
    }

    public void reset(View v) {

        setContentView(R.layout.nonlinear_values_animation);

    }

    // The evaluator calculates the current value of the property to be animated,
    //   taking into account the current progress of the animation (given by a fraction parameter between 0.0 and 1.0).
    // This evaluator is used to calculate the animation values for the x property such that the view will
    // be moved along a semicircle with radius 'radius'.

    class MyFloatEvaluator implements TypeEvaluator<Float> {

        public Float evaluate(float fraction, Float startValue, Float endValue) {

            float x = (float) (startValue.floatValue() + 2*radius*Math.sqrt(fraction*(1-fraction)));
            return x;

        }

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - Type Evaluator</H2>\n" +
                "As already explained, the property values in an animation are calculated by an evaluator method <font face=\"Courier\">evaluate()</font>. " +
                "In the default case, this is a simple linear interpolation between the start and the end value. " +
                "It is, however, possible to write an evaluator of one's own, " +
                "whose <font face=\"Courier\">evaluate()</font> method can implement any formula to calculate the property value. " +
                "Moreover, this evaluator can be applied to properties of any type whereas the given evaluators are limited to a set of selected types " +
                "like <font face=\"Courier\">Integer</font>, <font face=\"Courier\">Float</font> etc.<P>" +
                "<B>Programming steps</B><P>" +
                "These are the programming steps when using a type evaluator:" +
                "<UL><LI>Step 1: Implement the <font face=\"Courier\">TypeEvaluator</font> interface<BR>" +
                "<font face=\"Courier\">class MyEvaluator<BR> " +
                "&nbsp;implements TypeEvaluator<I>&lt;Type&gt;</I> {<BR> " +
                "&nbsp;&nbsp;public <I>Type</I><BR>&nbsp;&nbsp;&nbsp;evaluate(" +
                "<BR>&nbsp;&nbsp;&nbsp;&nbsp;float tf,<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;<I>Type</I> startValue,<BR>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;<I>Type</I> endValue) {<BR>" +
                "&nbsp;&nbsp;... <I>calculate and return the property value<BR>" +
                "&nbsp;&nbsp;at time tf</I> ...<BR>" +
                "&nbsp;}<BR>}</font><BR>" +
                "Note that <font face=\"Courier\">TypeEvaluator</font> is a generic interface " +
                "where <font face=\"Courier\"><I>Type</I></font> is the class of the animated property. " +
                "It would, e.g., be <font face=\"Courier\">Float</font> for the x position of a view " +
                "but can be any class.<P>" +
                "<LI>Step 2: Create an <font face=\"Courier\">ObjectAnimator</font> object and set its type evaluator<BR>" +
                "<font face=\"Courier\">ObjectAnimator myObjAnim = ...;<BR>" +
                "myObjAnim.setEvaluator(<BR>&nbsp;new MyEvaluator());</font><P>" +
                "<LI>Step 3: Start the animation<BR>" +
                "<font face=\"Courier\">myObjAnim.setDuration(...);<BR>" +
                "myObjAnim.start();</font></UL>";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_PropValueCalc_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_objectanimator_propvaluecalc+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#type-evaluator")).show();
    }

}
