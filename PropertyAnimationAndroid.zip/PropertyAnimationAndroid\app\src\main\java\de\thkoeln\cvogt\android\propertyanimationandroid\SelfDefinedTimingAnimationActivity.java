package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 31.7.2019

// This activity demonstrates how to specify the timing of an animation

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class SelfDefinedTimingAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.self_defined_timing_animation);

    }

    public void startAnimation(View v) {

        int duration = 2000;  // duration of the animation in ms
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        TextView animatedView1 = (TextView) findViewById(R.id.view5a);
        float endY1 = screenHeight - animatedView1.getHeight() - 300;

        ObjectAnimator animY1 = ObjectAnimator.ofFloat(animatedView1, "y", endY1);

        // set its TimeInterpolator to map the real time axis to a virtual time axis,
        //  thus "stretching" or "compressing" the time axis (see below for a detailed explanation)
        animY1.setInterpolator(new IncreasingSpeedTimeInterpolator()); // see detailed comment below
        animY1.setDuration(duration);
        animY1.start();

        TextView animatedView2 = (TextView) findViewById(R.id.view5b);
        float endY2 = screenHeight - animatedView2.getHeight() - 300;

        ObjectAnimator animY2 = ObjectAnimator.ofFloat(animatedView2, "y", endY2);

        animY2.setInterpolator(new JumpyTimeInterpolator()); // see detailed comment below
        animY2.setDuration(duration);
        animY2.start();

    }

    // two time interpolators

    class JumpyTimeInterpolator implements TimeInterpolator {

    // The TimeInterpolator defines a getInterpolation() method, which receives the actual (= real) time
    // as a parameter. More precisely speaking: The method receives the fraction of the animation duration
    // passed so far, as a value between 0.0 and 1.0. getInterpolation() maps this real time value to a
    // virtual time value, also between 0.0 and 1.0. This virtual time value is then used by the ObjectAnimator
    // to calculate the current value of the object property.
    //  (The ObjectAnimator calls the function evaluate() of an evaluator. evaluate() calculates the value of the
    //   animated object property from the current time, i.e. fraction of the animation duration passed so far.
    //   The calculated value might e.g. be the current position of a View on its way from its initial
    //   position to its target position. The function is usually a linear one, e.g.
    //     current position = initial position + fraction passed * (target position - initial position). )
    // Mapping the real time to a virtual time before calling evaluate() allows to stretch or compress the time axis
    // (so to speak) under full program control, thus causing the ObjectAnimator to animate properties not linearly
    // but with varying speeds.
    //
    // This principle is best understood by having a look at the getInterpolation() method defined below.
    // It maps all real time values smaller than 0.25 to the virtual time 0.0. Thus, during the first quarter of the
    // animation, the ObjectAnimator takes this virtual time 0.0 as an input to its evaluate() function that calculates
    // the current object property value.
    // If, as it is the case here, the property is the position of a View on the screen and the
    // ObjectAnimator calculates the position by the linear function given above, then this position will not change
    // during the first quarter of the animation - it will always be the initial position of the view (i.e. its
    // position at time 0). In the second quarter, the view will be displayed at a position one quarter of its way to its
    // target position, because the interpolator then feeds the time value 0.25 into evaluate(), and so on.

        @Override
        public float getInterpolation(float input) {

            if (input < 0.25) return 0.0f;

            if (input < 0.5) return 0.25f;

            if (input < 0.75) return 0.5f;

            if (input < 0.99) return 0.75f;

            return 1.0f;

        }

    }

    class IncreasingSpeedTimeInterpolator implements TimeInterpolator {

        @Override
        public float getInterpolation(float input) {

            // The virtual time is calculated as the real time raised to the power of four and will hence be smaller than the real time
            // as long as input<1.0. Therefore, this simple calculation has the effect that the animation starts slower
            // than an animation with constant speed and will then catch up.

            return input*input*input*input;

        }

    }

    public void reset(View v) {

        setContentView(R.layout.self_defined_timing_animation);

    }

    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Property Animation: ObjectAnimator - Timing Behaviour (2)</H2>\n" +
                "<B>Timing behaviour in the default case</B><P>" +
                "Property animation means to change the value of a property over time. " +
                "This is done by using an <I>evaluator</I> with its method <font face=\"Courier\">evaluate(tfReal)</font>. " +
                "The parameter <font face=\"Courier\">tfReal</font> of this method is a floating point value between 0.0 and 1.0. " +
                "It specifies the fraction of the animation time elapsed so far. tfReal = 0.5 e.g. means that half of the time has passed. " +
                "<font face=\"Courier\">evaluate(tfReal)</font> returns the property value to be used at time tfReal.<P> " +
                "In the default case, an animation plays at constant speed. " +
                "It calls <font face=\"Courier\">evaluate(tfReal)</font> repeatedly with tfReal growing linearly from 0.0 to 1.0 " +
                "and sets the property of the animated object with the returned values.<P> " +
                "<B>Timing behaviour with a time interpolator</B><P>" +
                "It is, however, possible to call a <I>time interpolator</I> before the evaluator. " +
                "The time interpolator defines a method <font face=\"Courier\">getInterpolation(tfReal)</font> " +
                "that takes the real time (a value between 0.0 and 1.0, as described above) as its parameter " +
                "and returns a <I>virtual time tfVirt</I> which is then used to call <font face=\"Courier\">evaluate(tfVirt)</font>. " +
                "tfVirt is also a value between 0.0 and 1.0 which may be smaller or larger than tfReal. " +
                "If tfVirt is smaller than tfReal then <font face=\"Courier\">evaluate(tfVirt)</font> returns (at instant tfReal!) " +
                "a property value that corresponds to an instant earlier than tfReal - the animation is therefore slower than in the default case. " +
                "Correspondingly, the animation is faster if tfVirt is larger than tfReal.<P> " +
                "For example, the time evaluator formula tfVirt = tfReal*tfReal*tfReal*tfReal maps tfReal values that are close to 0.0 " +
                "to tfVirt values that are very much smaller than tfReal. " +
                "With growing tfReal, the difference between tfVirt and tfReal will shrink more and more. " +
                "This means that the animation starts slowly and then speeds up.<P> " +
                "<B>Programming steps</B><P>" +
                "These are the programming steps when using a time interpolator:" +
                "<UL><LI>Step 1: Implement the <font face=\"Courier\">TimeInterpolator</font> interface<BR>" +
                "<font face=\"Courier\">class MyInterpolator<BR> " +
                "&nbsp;implements TimeInterpolator {<BR> " +
                "&nbsp;&nbsp;public float<BR>&nbsp;&nbsp;&nbsp;getInterpolation(<BR>&nbsp;&nbsp;&nbsp;&nbsp;float tf_real) {<BR>" +
                "&nbsp;&nbsp;... <I>calculate tf_virt</I> ...<BR>" +
                "&nbsp;&nbsp;return tf_virt;<BR>" +
                "&nbsp;}<BR>}</font><P>" +
                "<LI>Step 2: Create an <font face=\"Courier\">ObjectAnimator</font> object and set its time interpolator<BR>" +
                "<font face=\"Courier\">ObjectAnimator myObjAnim = ...;<BR>" +
                "myObjAnim.setInterpolator(<BR>&nbsp;new MyInterpolator());</font><P>" +
                "<LI>Step 3: Start the animation<BR>" +
                "<font face=\"Courier\">myObjAnim.setDuration(...);<BR>" +
                "myObjAnim.start();</font></UL>" +
                "<B>Video</B><P>" +
                "It is recommended to also watch the video as it includes some instructive illustrations.";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_Timing2_480.mp4")).show();
        (new Utils.VideooutputPopup(this,R.raw.propanim_objectanimator_timing2+"")).show();
    }

    private void explainWithAndroidDocu() {
        (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#interpolators")).show();
        // (new Utils.WebViewPopup(this,"https://developer.android.com/reference/android/animation/TimeInterpolator.html")).show();
    }

}
