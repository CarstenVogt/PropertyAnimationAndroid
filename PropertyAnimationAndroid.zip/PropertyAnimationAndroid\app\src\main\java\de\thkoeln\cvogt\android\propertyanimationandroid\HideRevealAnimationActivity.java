package de.thkoeln.cvogt.android.propertyanimationandroid;

// Prof. Dr. Carsten Vogt
// Technische Hochschule Köln, Germany
// Faculty of Information, Media, and Electrical Engineering
// http://www.nt.th-koeln.de/vogt
// 2.9.2019

// This activity demonstrates three animation types to hide and reveal views,
// as described in https://developer.android.com/training/animation/reveal-or-hide-view

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.ImageView;
import android.widget.PopupMenu;

public class HideRevealAnimationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hide_reveal_animation);
    }

    public void startAnimation(View v) {
        (findViewById(R.id.circularreveal_view)).post(new Runnable() {
            @Override
            public void run() {
                circular();
            }
        });
        (findViewById(R.id.crossfade_viewout)).post(new Runnable() {
            @Override
            public void run() {
                crossfade();
            }
        });
        (findViewById(R.id.card_front)).post(new Runnable() {
            @Override
            public void run() {
                flip();
            }
        });
    }

    public void reset(View v) {

        setContentView(R.layout.hide_reveal_animation);

    }

    public void circular() {
        // Let a view appear by revealing its pixels (= making them visible) stepwise around its center
        final ImageView image = (ImageView) findViewById(R.id.circularreveal_view);
        Animator anim = ViewAnimationUtils.createCircularReveal(image, (int)(image.getX()+image.getWidth()/2), (int)(image.getY()+image.getHeight()/2), 0, 400);
        anim.setDuration(4000);
        image.setVisibility(View.VISIBLE);
        anim.start();
    }

    public void crossfade() {
        // Let one view fade out and, at the same time, a second view fade in
        // by animating their alpha (= transparency) properties.
        final View viewOut = findViewById(R.id.crossfade_viewout);
        final View viewIn = findViewById(R.id.crossfade_viewin);
        viewIn.setAlpha(0f);
        viewIn.setVisibility(View.VISIBLE);
        viewOut.animate()
                .alpha(0f)
                .setDuration(4000);
        viewIn.animate()
                .alpha(1f)
                .setDuration(4000);
    }

    public void flip() {
        // Flip one view out and, at the same time, a second view in (like flipping a card)
        // by animating their rotation properties.
        final View front = findViewById(R.id.card_front);
        final View back = findViewById(R.id.card_back);
        AnimatorSet anim_in = (AnimatorSet) AnimatorInflater.loadAnimator(this,R.animator.flip_card_in_animator);
        anim_in.setTarget(back);
        AnimatorSet anim_out = (AnimatorSet) AnimatorInflater.loadAnimator(this,R.animator.flip_card_out_animator);
        anim_out.setTarget(front);
        anim_in.start();
        anim_out.start();
    }

/*
    public void explain(View v) {

        PopupMenu menu = new PopupMenu(this,v);
        menu.getMenuInflater().inflate(R.menu.menu_explain,menu.getMenu());
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.menuitem_text)
                    explainWithText();
                if (item.getItemId()==R.id.menuitem_video)
                    explainWithVideo();
                if (item.getItemId()==R.id.menuitem_androiddoc)
                    explainWithAndroidDocu();
                return true;
            }
        });
        Utils.setMenuFont(menu.getMenu());
        menu.show();

    }

    private void explainWithText() {

        String explanation =
                "<H2>Hiding and revealing views</H2>\n" +
                        "Not yet available";

        (new Utils.HTMLOutputPopup(this,explanation)).show();

    }

    private void explainWithVideo() {
        Utils.showBigToast(this,"Not yet available");
        // (new Utils.VideooutputPopup(this,"http://www.nt.th-koeln.de/vogt/vma/videos/PropAnim_ObjectAnimator_Timing2_480.mp4")).show();
    }

    private void explainWithAndroidDocu() {
        Utils.showBigToast(this,"Not yet available");
        // (new Utils.WebViewPopup(this,"https://developer.android.com/guide/topics/graphics/prop-animation#interpolators")).show();
    }

*/

}
